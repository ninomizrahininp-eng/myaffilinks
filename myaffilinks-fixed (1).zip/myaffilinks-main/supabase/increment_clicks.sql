-- ============================================================
-- RPC : increment_clicks
-- À coller dans Supabase > SQL Editor et exécuter une fois.
--
-- Remplace le fallback manuel (read → write) par une opération
-- atomique → plus de race condition si 2 clics arrivent en même temps.
-- ============================================================

CREATE OR REPLACE FUNCTION increment_clicks(uid uuid)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
AS $$
  UPDATE profiles
  SET total_clicks = COALESCE(total_clicks, 0) + 1
  WHERE user_id = uid;
$$;

-- Vérification rapide : la fonction doit apparaître dans la liste
-- SELECT routine_name FROM information_schema.routines WHERE routine_name = 'increment_clicks';
